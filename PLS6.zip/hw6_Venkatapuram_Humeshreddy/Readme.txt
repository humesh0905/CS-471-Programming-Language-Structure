Name: Humesh Reddy Venkatapuram
Date: 04/09/2000


-The task involves showcasing the concept of concurrency to calculate the highest, lowest, and average values of a matrix with different dimensions.

-This project was done on my ASUS Zenbook, which features an 11th-generation Intel Core i5-1135 processor and 8GB of memory.

-The objective is to compare the time taken to calculate the maximum value using concurrency with threads, without concurrency, and in the absence of threads.

-The code for computing the minimum, maximum, and average values were executed five times for each matrix, and the average values were recorded for analysis.
import java.io.*;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Matrix {
  
  
  
public static int N=0;
public static int [] [] mat;
public static int m,n,i,j;
public static float sum =0, average;

static void maxMin(int mat[][], int n)
{
  int min = Integer.MAX_VALUE;
  int max = Integer.MIN_VALUE;
     for(int i = 0; i < n; i++) {
      for(int j = 0; j < n; j++) {
        if(max < mat[i][j]) max = mat[i][j];
      }
    }
    
    
     for(int i = 0; i < n; i++) {
      for(int j = 0; j < n; j++) {
        if(min > mat[i][j]) min = mat[i][j];
      }
    }
    System.out.println("Maximum = " + max + ", Minimum = " + min);
}
    public static void main(String[] args)
    {
      
      Scanner in = null;
      try 
      {
        
        in = new Scanner(System.in);
        System.out.println("enter the dimenstion");
        N = in.nextInt();
        mat = new int[N][N];
        int base = 2;
        int minexponent = 31-N;
        int min = 10;
        int max = 100;
        int maxexponent = 32-N;
        for (int i=1;i<=minexponent;i++)
        {
          min = min*base;
          
        }
        for (int j=1;j<=maxexponent;j++)
        {
          max = max*base;
          
        }
        System.out.println("range is "+min +"," +max);
        for(int i =0;i<N;i++)
        {
          
          for (int j=0;j<N;j++)
          {
            Random r = new Random();
            mat[i][j] = r.nextInt((max-min)+1)+min;
          }
        }
        
        for (int i=0;i<N;i++)
        {
          for (int j=0;j<N;j++)
          {
            System.out.println(mat[i][j]+ " ");
            
          }
          System.out.println();
        }
        
        
        
        for (int i =0;i<N;i++)
        {
          for (int j=0;j<N;j++)
          {
            sum = sum + mat[i][j];
            
            
          }
        }
        average=sum/(N*N);
        System.out.printf("AVERAGE of the elements of the matrix = %.2f",average) ;
        
        
      }
    catch (Exception e) {
}
finally {
  in.close();
}
        maxMin(mat, N);
      
        // Custom input 2D array
        // int mat[][] = { { 1, 3, 4, 19 },
        //                 { 11, 10, 12, 1 },
        //                 { 7, 9, 0, 99 } };
        // Calling the method 1 that is recursive function to
        // find out maximum element
        // int max_element = max(mat, 0, 0);
        // int main_element = min(mat, 0, 0);
 
        // // Print and display the maximum element
        // System.out.println(max_element);
        // System.out.println(min_element);
    }
}
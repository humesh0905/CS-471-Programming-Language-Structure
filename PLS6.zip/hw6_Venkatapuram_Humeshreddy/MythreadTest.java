import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Random;
import java.util.concurrent.TimeUnit;
//import java.util.Math;
public class MythreadTest
{
//Here we declare the array list for threads and declare static variables so that they
//can be used accross various blocks.
private static ArrayList<Thread> arrThreads = new ArrayList<Thread>();
public static ArrayList<ThreadTest> arr = new ArrayList<ThreadTest>();
public static int N=0;
public static int[][] A;
public static int m, n, i, j;
public static void main(String[] args)
{
Scanner in = null;
try {
in = new Scanner(System.in);
//here we enter the dimensions of the matrix.
System.out.println("Enter the dimention of the matrix");
N = in.nextInt();
// Declare the matrix
A = new int[N][N];
// Read the matrix values
//System.out.println("Enter the elements of the matrix");
//Here we calculate the range of elements given in the question.
int base = 2;
int minexponent = 31-N;
int min =10;
int max =100;
int maxexponent = 32-N;
for(int i =1;i<minexponent;i++)
{
min= min*base;
}
for(int i =1;i<maxexponent;i++)
{
max = max*base;
}
System.out.println("range is "+min +"," +max);
for (i = 0; i < N; i++)
{
for (j = 0; j < N; j++)
{
Random r = new Random();
//Here we fill the matrix with random values.
A[i][j] =r.nextInt((max-min)+1)+min;
}
}
// Display the elements of the matrix
//System.out.println("Elements of the matrix are");
for (i = 0; i < N; i++)
{
for (j = 0; j < N; j++)
{
System.out.print(A[i][j] + " ");
}
System.out.println();
}
long startTime = System.nanoTime();
for(int k=0; k<N; k++)
{
//Here we create the threads.
Thread T1 = new Thread(new ThreadTest(k));
T1.start();
arrThreads.add(T1);
}
for (int i = 0; i < arrThreads.size(); i++)
{
//Here we join all the threads.
arrThreads.get(i).join();
}
//Here we calculate the total minimum, maximum and average values.
int matmin =arr.get(0).min ;
int matmax = arr.get(0).max;
float matsum =arr.get(0).average ;
float matavg =0;
for (int i = 1; i < arr.size(); i++)
{
//System.out.println(arr.get(i).min);
//System.out.println("&&&&&" +arr.get(i).min);
if( matmin > arr.get(i).min )
{
matmin = arr.get(i).min;
}
if( matmax < arr.get(i).max )
{
matmax = arr.get(i).max;
}
matsum = matsum + arr.get(i).average;
}
matavg = matsum/N;
long endTime = System.nanoTime();
long timeElapsed = endTime - startTime;
System.out.println("Execution time in nanoseconds: " + timeElapsed);
System.out.println( "minimum is " +matmin);
System.out.println("maximum is " +matmax);
System.out.printf("average is %f" , matavg);
}
catch (Exception e) {
}
finally {
in.close();
}
}
}
class ThreadTest implements Runnable
{
//here we define the class for individual threads.
public int i;
public int min = 0;
public int max = 0;
public float average = 0;
ThreadTest(int ind)
{
i = ind;
}
public void run()
{
try
{
int sum = 0;
min = MythreadTest.A[i][0];
max = MythreadTest.A[i][0];
sum = MythreadTest.A[i][0];
//here we acess the elements of the individual rows and calculate the
//min,max and average of the individual roqs.
for (int k = 1; k < MythreadTest.N; k++)
{
if( min > MythreadTest.A[i][k] )
{
min = MythreadTest.A[i][k];
}
if(max < MythreadTest.A[i][k])
{
max = MythreadTest.A[i][k];
}
sum = sum + MythreadTest.A[i][k];
}
average = sum/MythreadTest.N;
// System.out.println(" Thread: " + i + " min: " + min + " max: " + max + "
// Average: " + average + "\n");
MythreadTest.arr.add(this);
Thread.sleep(1000);
//System.out.println("Thread is exiting " + i);
}
catch (Exception e)
{
System.out.println(e.getMessage());
}
}
}